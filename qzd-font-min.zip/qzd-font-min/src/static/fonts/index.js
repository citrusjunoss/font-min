import fs from 'fs';
import Fontmin from 'fontmin';
import path from 'path';
import fonteditor from 'fonteditor-core'
import { b2ab } from 'b3b'


const __dirname = path.resolve()

const joinPath  = (str) => {
  return  path.join(__dirname, '/src', str)
}
const filePath = joinPath('/static/fonts/files')
// const fontmin = new Fontmin()


// fontmin.src(path.join(filePath, 'FangZhengHeiTiJianTi-1.ttf')).use(Fontmin.glyph({
//     text: '宇宙洪荒',
// })).dest(path.join('dist')).run((e, f) => {
//     const ttfobj = new fonteditor.TTFReader().read(b2ab(f));
//     ttfobj.glyf.map(item => {
//     console.log('unicide', item)
//     // item.unicode ? String.fromCodePoint(item.unicode) : ''
//     })
// })
fs.readFile('dist/FangZhengHeiTiJianTi-1.ttf', (e, f) => {
    const ttfobj = new fonteditor.TTFReader().read(b2ab(f));
    ttfobj.glyf.filter(item => item.unicode).map(item => {
        console.log(String.fromCodePoint(item.unicode))
    })
})

// fs.readdir(filePath, (e, file) => {
//     file.map(item => {
 
        // fs.readFile(path.join(filePath, item), (err, file) => {
        //     const ttfobj = new fonteditor.TTFReader().read(b2ab(file));
        //     ttfobj.glyf.slice(0, 10).filter(item => item.unicode).map(item => {
        //         console.log('unicide', item.unicode, item.unicode.map(item => String.fromCodePoint(item)))
        //         // item.unicode ? String.fromCodePoint(item.unicode) : ''
        //      }
        //     )

        // })
        // fontmin.run((err, file) => {
        //    console.log(file)
        // })
//     })
// })